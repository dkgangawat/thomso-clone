const SideBar = [
    {
        "id": 21,
        "name": "Technical Workshops"
    },
    {
        "id": 4,
        "name": "Cultural Workshops"
    },
    {
        "id": 2,
        "name": "Choreo"
    },
    {
        "id": 6,
        "name": "Dramatics"
    },
    {
        "id": 22,
        "name": "Crypto and Investing Workshop"
    },
    {
        "id": 18,
        "name": "Gaming"
    },
    {
        "id": 5,
        "name": "Music"
    },
    {
        "id": 7,
        "name": "Quizzing"
    },
    {
        "id": 8,
        "name": "Cinematic"
    },
    {
        "id": 10,
        "name": "Entertainment"
    },
    {
        "id": 11,
        "name": "Marketing & Finance"
    },
    {
        "id": 14,
        "name": "Fashion"
    },
    {
        "id": 16,
        "name": "Online"
    },
    {
        "id": 17,
        "name": "Culinary"
    },
    {
        "id": 20,
        "name": "Da Vinci's Gala"
    },
    {
        "id": 19,
        "name": "Adventure"
    },
    {
        "id": 9,
        "name": "LITFest"
    },
    {
        "id": 15,
        "name": "MUN"
    },
    {
        "id": 12,
        "name": "Nightlife"
    },
    {
        "id": 13,
        "name": "Carnival"
    }
]

export default SideBar