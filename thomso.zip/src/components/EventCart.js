import React from 'react'

const EventCart = () => {
  return (
    <div className='card'>
      <div className='card-media'>
        <img src="" alt="" />
      </div>
      <div className='card-text'>
        <div className='card-heading'></div>
        <div className='card-category'></div>
      </div>
    </div>
  )
}

export default EventCart